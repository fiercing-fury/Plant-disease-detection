# 🌿 Plant Disease Detection using CNN

This project uses a Convolutional Neural Network (CNN) to detect plant diseases from leaf images.

## 🔧 Features
- Upload leaf images via a web app (Flask)
- Predict plant disease with confidence score
- Uses pre-trained model in TensorFlow/Keras

## 📁 Folder Structure
```
Plant-Disease-Detection/
├── app.py
├── requirements.txt
├── README.md
├── templates/
│   └── index.html
├── static/             # For uploaded images
├── model/
│   └── model.h5        # Pre-trained model
```

## 🚀 How to Run
1. Clone the repo
2. Install requirements:
   ```bash
   pip install -r requirements.txt
   ```
3. Place `model.h5` inside the `model/` folder
4. Run the app:
   ```bash
   python app.py
   ```
5. Open browser at `http://127.0.0.1:5000`

## 📷 Example
Upload a leaf image and get instant prediction.

## 🧠 Model Info
Trained on PlantVillage dataset (customizable).

---
Built with ❤️ by Deepak
